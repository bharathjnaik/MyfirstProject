// ===== 1. EDIT THESE =====
export const CFG = {
  whatsapp: "919999999999",            // country code + number, no + or spaces
  email: "yourmail@gmail.com",
  instagram: "https://instagram.com/yourname",
  youtube: "https://youtube.com/@yourchannel",
  // Paste your Firebase web config here (Firebase Console > Project settings > Your apps).
  // Leave apiKey empty to run in DEMO mode (orders saved only in this browser).
  firebase: { apiKey: "", authDomain: "", projectId: "", storageBucket: "", messagingSenderId: "", appId: "" }
};

const SERVICES = [
  ["YouTube Video Editing","Cuts, captions, music, thumbnails-ready exports.","₹499","▶️"],
  ["Instagram Reels Editing","Beat-synced trendy reels that hold attention.","₹199","📱"],
  ["Wedding Video Editing","Emotional highlights with cinematic grading.","₹2999","💍"],
  ["Birthday Video Editing","Fun memories turned into a lovely film.","₹399","🎂"],
  ["Cinematic Video Editing","Film look, colour grade, sound design.","₹999","🎞️"],
  ["Promotional Video Editing","Sharp promos that sell your brand.","₹799","📣"],
  ["Birthday Invitation Video","Animated invites ready to share on WhatsApp.","₹299","💌"],
  ["Business Advertisement Editing","Ads for shops, products and services.","₹899","🏪"],
  ["Gaming Video Editing","Montages, highlights, effects and memes.","₹499","🎮"],
  ["Shorts & Trending Edits","Quick viral-style edits for Shorts/Reels.","₹149","🔥"]
];
const hues = [270,290,330,20,220,250,310,190,140,0];

const $ = s => document.querySelector(s);
$("#cards").innerHTML = SERVICES.map((s,i)=>`
 <div class="card rv"><div class="art" style="background:linear-gradient(135deg,hsl(${hues[i]},70%,28%),hsl(${(hues[i]+60)%360},70%,16%))">${s[3]}</div>
 <div class="bd"><h3>${s[0]}</h3><p>${s[1]}</p><span class="pr">Starting ${s[2]}</span>
 <a class="btn sm" href="#order" data-svc="${s[0]}">Order Now</a></div></div>`).join("");
$("#svcSel").innerHTML += SERVICES.map(s=>`<option>${s[0]}</option>`).join("");
document.addEventListener("click",e=>{const a=e.target.closest("[data-svc]");if(a)$("#svcSel").value=a.dataset.svc});

$("#wa").href = `https://wa.me/${CFG.whatsapp}?text=Hi%20BHARATH%20EDITZ`;
$("#mail").href = `mailto:${CFG.email}`; $("#ig").href = CFG.instagram; $("#yt").href = CFG.youtube;

const io = new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add("in")),{threshold:.15});
document.querySelectorAll(".sec h2,.card,blockquote,.about").forEach(el=>{el.classList.add("rv");io.observe(el)});

// ===== Firebase (loaded only if configured) =====
let fb = null;
if (CFG.firebase.apiKey) {
  const B = "https://www.gstatic.com/firebasejs/10.12.2/";
  const [app, fs, st] = await Promise.all([import(B+"firebase-app.js"),import(B+"firebase-firestore.js"),import(B+"firebase-storage.js")]);
  const a = app.initializeApp(CFG.firebase);
  fb = { db: fs.getFirestore(a), storage: st.getStorage(a), ...fs, ...st };
}

const newId = () => "BE" + Date.now().toString(36).toUpperCase().slice(-6) + Math.floor(Math.random()*36).toString(36).toUpperCase();

$("#orderForm").addEventListener("submit", async e => {
  e.preventDefault();
  const f = e.target, d = Object.fromEntries(new FormData(f)), err = $("#err");
  err.textContent = "";
  if (!d.name.trim() || !/^\S+@\S+\.\S+$/.test(d.email) || d.whatsapp.replace(/\D/g,"").length < 10 ||
      !d.service || !d.duration || !d.pack || !d.req.trim()) { err.textContent = "Please fill all required fields correctly."; return; }
  const files = [...$("#files").files]; if (!files.length) { err.textContent = "Please upload at least one photo or video."; return; }
  const ref = $("#ref").files[0], id = newId(), btn = f.querySelector("button"), prog = $("#prog");
  btn.disabled = true; btn.textContent = "Uploading…"; prog.hidden = false;
  const order = { id, name:d.name, email:d.email, whatsapp:d.whatsapp, service:d.service, duration:d.duration, pack:d.pack,
    req:d.req, extra:d.extra, deliveryDate:d.date||"", status:"Order Received", payment:"Pending", charges:0, files:[], created:Date.now() };
  try {
    if (fb) {
      const all = [...files, ...(ref?[ref]:[])], total = all.reduce((t,x)=>t+x.size,0); let done = 0;
      for (const file of all) {
        const r = fb.ref(fb.storage, `orders/${id}/${Date.now()}_${file.name}`);
        const task = fb.uploadBytesResumable(r, file); let last = 0;
        await new Promise((ok,no)=>task.on("state_changed",s=>{done+=s.bytesTransferred-last;last=s.bytesTransferred;prog.value=done/total*100},no,ok));
        order.files.push({ name:file.name, path:r.fullPath, ref:file===ref });
      }
      await fb.setDoc(fb.doc(fb.db,"orders",id), order);
    } else {
      order.files = files.map(x=>({name:x.name}));
      localStorage.setItem("order_"+id, JSON.stringify(order));
    }
    f.hidden = true;
    const msg = encodeURIComponent(`Hi BHARATH EDITZ, I placed order ${id} for ${d.service}.`);
    $("#done").hidden = false;
    $("#done").innerHTML = `<h3>✅ Order Confirmed!</h3><p>Your Order ID</p><b>${id}</b><p>Save this ID to track your order.</p>
      ${fb?"":"<p class='err'>Demo mode: connect Firebase to receive real files.</p>"}
      <a class="btn" target="_blank" rel="noopener" href="https://wa.me/${CFG.whatsapp}?text=${msg}">Message on WhatsApp</a>`;
    $("#done").scrollIntoView({behavior:"smooth"});
  } catch (x) { console.error(x); err.textContent = "Upload failed. Check internet and try again."; btn.disabled = false; btn.textContent = "SUBMIT ORDER"; }
});

$("#tbtn").onclick = async () => {
  const id = $("#tid").value.trim().toUpperCase(), box = $("#tres"); if (!id) return;
  let o = null;
  try {
    if (fb) { const s = await fb.getDoc(fb.doc(fb.db,"orders",id)); o = s.exists()?s.data():null; }
    else o = JSON.parse(localStorage.getItem("order_"+id) || "null");
  } catch (x) { console.error(x); }
  box.hidden = false;
  box.innerHTML = !o ? "Order not found. Check your Order ID." :
    `<b>${o.status}</b><p>${o.service} • Payment: ${o.payment}${o.charges?` • ₹${o.charges}`:""}</p>
     ${o.deliveryMsg?`<p>${o.deliveryMsg}</p>`:""}
     ${o.finalUrl?`<a class="btn" href="${o.finalUrl}" target="_blank" rel="noopener" download>⬇ Download Video (HD)</a>`:""}`;
};
